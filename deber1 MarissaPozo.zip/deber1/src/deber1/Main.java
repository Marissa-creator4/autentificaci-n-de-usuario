package deber1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        User user = new User();

        
        if (!user.login()) {
            return;
        }

        
        System.out.print("Ingrese número de personas: ");
        int n = sc.nextInt();
        sc.nextLine();

        Person[] personas = new Person[n];

        char opcion;

        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("Registrar--r");
            System.out.println("Listar nombres--n");
            System.out.println("Buscar--s");
            System.out.println("Actualizar--u");
            System.out.println("Salir--x");
            System.out.print("Opción: ");
            opcion = sc.next().charAt(0);
            sc.nextLine();

            switch (opcion) {

                case 'r':
                    for (int i = 0; i < n; i++) {
                        if (personas[i] == null) {
                            System.out.println("Registro #" + (i + 1));

                            System.out.print("Nombre: ");
                            String nombre = sc.nextLine();

                            System.out.print("Edad: ");
                            int edad = sc.nextInt();
                            sc.nextLine();

                            System.out.print("Teléfono: ");
                            String telefono = sc.nextLine();

                            System.out.print("DNI: ");
                            String dni = sc.nextLine();

                            personas[i] = new Person(nombre, edad, telefono, dni);
                            break;
                        }
                    }
                    break;

                case 'n':
                    for (Person p : personas) {
                        if (p != null) {
                            System.out.println(p.nombre);
                        }
                    }
                    break;

                case 's':
                    System.out.print("Ingrese nombre a buscar: ");
                    String buscar = sc.nextLine();

                    for (Person p : personas) {
                        if (p != null && p.nombre.equalsIgnoreCase(buscar)) {
                            p.mostrar();
                        }
                    }
                    break;

                case 'u':
                    System.out.print("Ingrese DNI a actualizar: ");
                    String dniBuscar = sc.nextLine();

                    for (int i = 0; i < personas.length; i++) {
                        if (personas[i] != null && personas[i].dni.equals(dniBuscar)) {

                            System.out.print("Nuevo nombre: ");
                            personas[i].nombre = sc.nextLine();

                            System.out.print("Nueva edad: ");
                            personas[i].edad = sc.nextInt();
                            sc.nextLine();

                            System.out.print("Nuevo teléfono: ");
                            personas[i].telefono = sc.nextLine();

                            System.out.println("Actualizado correctamente");
                        }
                    }
                    break;

            }

        } while (opcion != 'x');

        System.out.println("Programa finalizado");
    }
}
