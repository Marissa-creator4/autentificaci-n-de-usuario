package deber1;

import java.util.Scanner;

public class User {
    private String usuario = "admin";
    private String contraseña = "admin123";

    public boolean login() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese usuario: ");
        String u = sc.nextLine();

        System.out.print("Ingrese contraseña: ");
        String c = sc.nextLine();

        if (u.equals(usuario) && c.equals(contraseña)) {
            System.out.println("Acceso correcto\n");
            return true;
        } else {
            System.out.println("Usuario o contraseña incorrectos\n");
            return false;
        }
    }
}