package deber1;

public class Person {
    String nombre;
    int edad;
    String telefono;
    String dni;

    public Person(String nombre, int edad, String telefono, String dni) {
        this.nombre = nombre;
        this.edad = edad;
        this.telefono = telefono;
        this.dni = dni;
    }

    public void mostrar() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Teléfono: " + telefono);
        System.out.println("DNI: " + dni);
        System.out.println("----------------------");
    }
}